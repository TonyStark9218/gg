const CONFIG = {
    TOKEN: "8093389141:AAE5U0DCAUrt42-R7_Sm-NYOHqRaMpWXJRU",
    OWNER_ID: 6554270458
};

const REDIRECT_URL = "https://gg-chi-one.vercel.app";
let sessionBlocklist = [];
let permBlocklist = [];
let domainBlocklist = [];
let keywordBlocklist = [];
let scheduledBlocks = [];
let blockLog = [];
let updateOffset = 0;
let connectionFailed = false;
let lastConnectionFailureMessage = 0;
const POLLING_INTERVAL = 5000; // 5s to avoid rate limits
const CONNECTION_MESSAGE_COOLDOWN = 5 * 60 * 1000; // 5 minutes
let notificationEnabled = true; // Default: notifications enabled
let lastTabInfo = {}; // Track last tab URL and timestamp

// Initialize
chrome.runtime.onInstalled.addListener(async () => {
    await setStorage('local', { 
        sessionBlocklist: [], 
        blockLog: [], 
        keywordBlocklist: [], 
        scheduledBlocks: [], 
        domainBlocklist: [], 
        notificationEnabled: true 
    });
    await setStorage('sync', { permBlocklist: [], lastActive: Date.now() });
    sendTelegramMessage('🚀 *WebGuard started!*');
});

// Keep-alive for service worker
setInterval(() => {
    setStorage('sync', { lastActive: Date.now() });
}, 5 * 60 * 1000);

// Load blocklists and notification state
(async () => {
    const localData = await getStorage('local', [
        'sessionBlocklist', 
        'blockLog', 
        'keywordBlocklist', 
        'scheduledBlocks', 
        'domainBlocklist', 
        'notificationEnabled'
    ]);
    sessionBlocklist = localData.sessionBlocklist || [];
    blockLog = localData.blockLog || [];
    keywordBlocklist = localData.keywordBlocklist || [];
    scheduledBlocks = localData.scheduledBlocks || [];
    domainBlocklist = localData.domainBlocklist || [];
    notificationEnabled = localData.notificationEnabled !== undefined ? localData.notificationEnabled : true;
    const syncData = await getStorage('sync', ['permBlocklist']);
    permBlocklist = syncData.permBlocklist || [];
})();

// Monitor tabs
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'loading' && tab.url && tab.url.startsWith('http')) {
        const url = tab.url;

        // Notify only if URL has changed or it's a new tab
        if (notificationEnabled && (!lastTabInfo[tabId] || lastTabInfo[tabId].url !== url)) {
            if (lastTabInfo[tabId] && lastTabInfo[tabId].url) {
                const duration = Math.round((Date.now() - lastTabInfo[tabId].timestamp) / 1000); // Duration in seconds
                sendTelegramMessage(`⏰ *Previous site: ${lastTabInfo[tabId].url}*\n🕒 *Open for: ${duration} seconds*`);
            }
            sendTelegramMessage(`🌐 *Site opened: ${url}*`);
        }

        // Update last tab info
        lastTabInfo[tabId] = { url, timestamp: Date.now() };

        // Check if URL is blocked
        if (isBlocked(url)) {
            blockLog.push({ url, timestamp: new Date().toISOString() });
            setStorage('local', { blockLog }).catch(() => sendTelegramMessage('❌ *Storage error: blockLog*'));
            sendTelegramMessage(`🚫 *Blocked: ${url}*`);
            chrome.tabs.remove(tabId, () => {
                if (chrome.runtime.lastError) {
                    sendTelegramMessage(`❌ *Tab close error: ${chrome.runtime.lastError.message}*`);
                    return;
                }
                chrome.tabs.create({ url: `${REDIRECT_URL}?url=${encodeURIComponent(url)}` }, () => {
                    if (chrome.runtime.lastError) {
                        sendTelegramMessage(`❌ *Redirect error: ${chrome.runtime.lastError.message}*`);
                    }
                });
            });
        }
    }
});

// Monitor tab closure to calculate duration
chrome.tabs.onRemoved.addListener((tabId) => {
    if (notificationEnabled && lastTabInfo[tabId]) {
        const duration = Math.round((Date.now() - lastTabInfo[tabId].timestamp) / 1000); // Duration in seconds
        sendTelegramMessage(`⏰ *Closed site: ${lastTabInfo[tabId].url}*\n🕒 *Open for: ${duration} seconds*`);
        delete lastTabInfo[tabId]; // Clean up
    }
});

// Uninstall prompt
chrome.runtime.onSuspend.addListener(() => {
    chrome.tabs.create({ url: chrome.runtime.getURL('uninstall.html') }, () => {
        if (chrome.runtime.lastError) {
            sendTelegramMessage(`❌ *Uninstall prompt error: ${chrome.runtime.lastError.message}*`);
        }
    });
});

// Check blocked URL
function isBlocked(url) {
    try {
        const urlObj = new URL(url);
        const hostname = urlObj.hostname.toLowerCase();
        const href = urlObj.href;
        const now = new Date();
        const currentTime = now.getHours() * 60 + now.getMinutes();

        if (keywordBlocklist.some(k => url.toLowerCase().includes(k.toLowerCase()))) return true;
        if (domainBlocklist.some(d => hostname === d || hostname.endsWith('.' + d))) return true;
        if (sessionBlocklist.includes(href)) return true;
        if (permBlocklist.includes(href)) return true;
        if (scheduledBlocks.some(b => {
            const [start, end] = b.time.split('-').map(t => {
                const [h, m] = t.split(':').map(Number);
                return h * 60 + m;
            });
            return b.url === href && currentTime >= start && currentTime <= end;
        })) return true;
        return false;
    } catch (e) {
        sendTelegramMessage(`❌ *Block check error: ${e.message}*`);
        return false;
    }
}

// Normalize domain
function normalizeDomain(input) {
    return input.replace(/^(https?:\/\/)?(www\.)?/, '').replace(/\/.*$/, '').toLowerCase();
}

// Telegram updates
function processTelegramUpdates(retryCount = 0) {
    fetch(`https://api.telegram.org/bot${CONFIG.TOKEN}/getUpdates?offset=${updateOffset}`)
        .then(res => res.json())
        .then(data => {
            if (!data.ok) {
                connectionFailed = true;
                if (retryCount < 3) {
                    setTimeout(() => processTelegramUpdates(retryCount + 1), 1000 * (retryCount + 1));
                }
                return;
            }

            if (connectionFailed) {
                const now = Date.now();
                if (now - lastConnectionFailureMessage > CONNECTION_MESSAGE_COOLDOWN) {
                    sendTelegramMessage('⚠ *Connection restored!*');
                    lastConnectionFailureMessage = now;
                }
                connectionFailed = false;
            }

            data.result.forEach(update => {
                if (update.message && update.message.from.id === CONFIG.OWNER_ID) {
                    handleMessage(update.message);
                }
                if (update.callback_query && update.callback_query.from.id === CONFIG.OWNER_ID) {
                    handleCallbackQuery(update.callback_query);
                    fetch(`https://api.telegram.org/bot${CONFIG.TOKEN}/answerCallbackQuery`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ callback_query_id: update.callback_query.id })
                    }).catch(() => sendTelegramMessage('❌ *Callback error*'));
                }
                updateOffset = update.update_id + 1;
            });
        })
        .catch(() => {
            connectionFailed = true;
            if (retryCount < 3) {
                setTimeout(() => processTelegramUpdates(retryCount + 1), 1000 * (retryCount + 1));
            }
        });
}

// Handle commands
function handleMessage(message) {
    const text = message.text || '';
    const [command, ...args] = text.split(' ');
    const input = args[0];
    const duration = parseInt(args[1]);
    const timeRange = args[1];

    if (command === '/start') {
        sendTelegramMessageWithButtons(
            '🚀 *WebGuard*',
            [
                [{ text: '🔒 Block Site', callback_data: '/block' }, { text: '🌐 Block Domain', callback_data: '/domainblock' }],
                [{ text: '🔓 Unblock', callback_data: '/unblock' }, { text: '🔑 Block Keyword', callback_data: '/blockkeyword' }],
                [{ text: '⏰ Schedule Block', callback_data: '/scheduleblock' }, { text: '📋 Blocklist', callback_data: '/blocklist' }],
                [{ text: '📊 Status', callback_data: '/status' }, { text: '📜 Logs', callback_data: '/logs' }],
                [{ text: '🔔 Toggle Notifications', callback_data: '/togglenotifications' }]
            ]
        );
    } else if (command === '/block') {
        if (!input) return sendTelegramMessage('❌ *Enter URL!*\nEx: /block https://www.instagram.com/baduser');
        const url = input.startsWith('http') ? input : `https://${input}`;
        if (!sessionBlocklist.includes(url)) {
            sessionBlocklist.push(url);
            setStorage('local', { sessionBlocklist }).catch(() => sendTelegramMessage('❌ *Storage error: sessionBlocklist*'));
            if (duration && !isNaN(duration)) {
                setTimeout(() => {
                    sessionBlocklist = sessionBlocklist.filter(u => u !== url);
                    setStorage('local', { sessionBlocklist });
                    sendTelegramMessage(`⏰ *Expired: ${url}*`);
                }, duration * 60 * 1000);
                sendTelegramMessage(`✅ *Blocked ${url} for ${duration} min*`);
            } else {
                sendTelegramMessage(`✅ *Blocked ${url}*`);
            }
        } else {
            sendTelegramMessage('⚠️ *Already blocked!*');
        }
    } else if (command === '/domainblock') {
        if (!input) return sendTelegramMessage('❌ *Enter domain!*\nEx: /domainblock instagram.com');
        const domain = normalizeDomain(input);
        if (!domainBlocklist.includes(domain)) {
            domainBlocklist.push(domain);
            setStorage('local', { domainBlocklist }).catch(() => sendTelegramMessage('❌ *Storage error: domainBlocklist*'));
            sendTelegramMessage(`✅ *Blocked domain: ${domain}*`);
        } else {
            sendTelegramMessage('⚠️ *Already blocked!*');
        }
    } else if (command === '/unblock') {
        if (!input) return sendTelegramMessage('❌ *Enter site/domain!*\nEx: /unblock instagram.com');
        const url = input.startsWith('http') ? input : `https://${input}`;
        const domain = normalizeDomain(input);
        let unblocked = false;
        if (sessionBlocklist.includes(url)) {
            sessionBlocklist = sessionBlocklist.filter(u => u !== url);
            setStorage('local', { sessionBlocklist });
            sendTelegramMessage(`✅ *Unblocked: ${url}*`);
            unblocked = true;
        }
        if (permBlocklist.includes(url)) {
            permBlocklist = permBlocklist.filter(u => u !== url);
            setStorage('sync', { permBlocklist });
            sendTelegramMessage(`✅ *Unblocked: ${url} (permanent)*`);
            unblocked = true;
        }
        if (domainBlocklist.includes(domain)) {
            domainBlocklist = domainBlocklist.filter(d => d !== domain);
            setStorage('local', { domainBlocklist });
            sendTelegramMessage(`✅ *Unblocked: ${domain} (domain)*`);
            unblocked = true;
        }
        if (!unblocked) sendTelegramMessage('⚠️ *Not blocked!*');
    } else if (command === '/blockkeyword') {
        if (!input) return sendTelegramMessage('❌ *Enter keyword!*\nEx: /blockkeyword social');
        if (!keywordBlocklist.includes(input)) {
            keywordBlocklist.push(input);
            setStorage('local', { keywordBlocklist }).catch(() => sendTelegramMessage('❌ *Storage error: keywordBlocklist*'));
            sendTelegramMessage(`✅ *Blocked keyword: ${input}*`);
        } else {
            sendTelegramMessage('⚠️ *Already blocked!*');
        }
    } else if (command === '/scheduleblock') {
        if (!input || !timeRange || !timeRange.match(/^\d{2}:\d{2}-\d{2}:\d{2}$/)) {
            return sendTelegramMessage('❌ *Enter site and time!*\nEx: /scheduleblock https://www.instagram.com 09:00-17:00');
        }
        const url = input.startsWith('http') ? input : `https://${input}`;
        scheduledBlocks.push({ url, time: timeRange });
        setStorage('local', { scheduledBlocks }).catch(() => sendTelegramMessage('❌ *Storage error: scheduledBlocks*'));
        sendTelegramMessage(`✅ *Scheduled: ${url} from ${timeRange}*`);
    } else if (command === '/blocklist') {
        const message = [
            '📋 *Blocklist*',
            sessionBlocklist.length ? `🔒 Sites:\n${sessionBlocklist.map(u => `- ${u}`).join('\n')}` : '🔒 Sites: None',
            permBlocklist.length ? `🔒 Permanent:\n${permBlocklist.map(u => `- ${u}`).join('\n')}` : '🔒 Permanent: None',
            domainBlocklist.length ? `🌐 Domains:\n${domainBlocklist.map(d => `- ${d}`).join('\n')}` : '🌐 Domains: None',
            keywordBlocklist.length ? `🔑 Keywords:\n${keywordBlocklist.map(k => `- ${k}`).join('\n')}` : '🔑 Keywords: None',
            scheduledBlocks.length ? `⏰ Scheduled:\n${scheduledBlocks.map(b => `- ${b.url} (${b.time})`).join('\n')}` : '⏰ Scheduled: None'
        ].join('\n');
        sendTelegramMessage(message);
    } else if (command === '/status') {
        chrome.tabs.query({}, (tabs) => {
            const message = [
                `📊 *Status*`,
                `🌐 Tabs: ${tabs.length}`,
                `🔒 Sites: ${sessionBlocklist.length}`,
                `🌐 Domains: ${domainBlocklist.length}`,
                `🔑 Keywords: ${keywordBlocklist.length}`,
                `⏰ Scheduled: ${scheduledBlocks.length}`,
                `🚫 Blocks: ${blockLog.length}`,
                `🔔 Notifications: ${notificationEnabled ? 'Enabled' : 'Disabled'}`
            ].join('\n');
            sendTelegramMessage(message);
        });
    } else if (command === '/logs') {
        const message = blockLog.length ? `📜 *Logs*\n${blockLog.map(log => `- ${log.url} at ${log.timestamp}`).join('\n')}` : '📜 *Logs*\nNone';
        sendTelegramMessage(message);
    } else if (command === '/togglenotifications') {
        notificationEnabled = !notificationEnabled;
        setStorage('local', { notificationEnabled }).catch(() => sendTelegramMessage('❌ *Storage error: notificationEnabled*'));
        sendTelegramMessage(`🔔 *Notifications ${notificationEnabled ? 'enabled' : 'disabled'}*`);
    } else {
        sendTelegramMessage('❌ *Invalid command!*');
    }
}

// Handle button callbacks
function handleCallbackQuery(callbackQuery) {
    const command = callbackQuery.data;
    if (['/block', '/domainblock', '/unblock', '/blockkeyword', '/scheduleblock'].includes(command)) {
        sendTelegramMessage(`📝 *Enter ${command}!*\nEx: ${command} instagram.com`);
    } else if (['/blocklist', '/status', '/logs', '/togglenotifications'].includes(command)) {
        handleMessage({ text: command });
    } else {
        sendTelegramMessage('❌ *Invalid button!*');
    }
}

// Send Telegram message with buttons
function sendTelegramMessageWithButtons(text, buttons) {
    fetch(`https://api.telegram.org/bot${CONFIG.TOKEN}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            chat_id: CONFIG.OWNER_ID,
            text,
            parse_mode: 'Markdown',
            disable_web_page_preview: true,
            reply_markup: { inline_keyboard: buttons }
        })
    }).catch(() => sendTelegramMessage('❌ *Telegram send error*'));
}

// Send Telegram message
function sendTelegramMessage(text) {
    fetch(`https://api.telegram.org/bot${CONFIG.TOKEN}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            chat_id: CONFIG.OWNER_ID,
            text,
            parse_mode: 'Markdown',
            disable_web_page_preview: true
        })
    }).catch(() => {});
}

// Storage helpers
async function getStorage(type, keys) {
    return new Promise(resolve => chrome.storage[type].get(keys, resolve));
}

async function setStorage(type, items) {
    return new Promise(resolve => chrome.storage[type].set(items, resolve));
}

// Start polling
setInterval(processTelegramUpdates, POLLING_INTERVAL);
processTelegramUpdates();